import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/painting.dart';
import 'package:carousel_slider/carousel_slider.dart';
import 'package:e_commerce/PhotoScreen/ImageViewer.dart';
import 'package:e_commerce/Payment.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:cached_network_image/cached_network_image.dart';

import 'DetailsTable.dart';
class ProductDetails extends StatefulWidget {
  String productId;
  String productName;
  @override
  ProductDetails({this.productId,this.productName});
  _ProductDetailsState createState() => _ProductDetailsState(productId: productId,productName: productName);
}

class _ProductDetailsState extends State<ProductDetails> {

  String productId;
  String productName;
  List<dynamic> imageUrls=[];


  static const rowStyle=TextStyle(fontSize: 16,color: Colors.black);
  String title="Payment Easy";
  TextEditingController controller= TextEditingController();

  //Firebase variable
  var _firestore=FirebaseFirestore.instance;

  _ProductDetailsState({this.productId,this.productName});

  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
          backgroundColor: Theme.of(context).primaryColor,
          title: Text("Product Details",
            style: TextStyle(
                color: Colors.white
            ),)
      ),
      body: Container(
        color: Colors.white,
        child: ListView(
          children: [
            Padding(
              padding: EdgeInsets.symmetric(vertical: 20,horizontal: 20),
              child: Card(
                shadowColor: Colors.lightBlueAccent,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(25)
                ),
                elevation: 9,
                child: Container(
                  margin: EdgeInsets.all(5),
                  child: Padding(
                    padding: const EdgeInsets.all(10.0),
                    child: Center(
                      child: Text(
                        productName,
                        style: TextStyle(
                          fontFamily: 'YuseiMagic',
                            fontSize: 18,
                            fontWeight: FontWeight.w400,
                            color: Colors.black87
                        ),),
                    ),
                  ),
                ),
              ),
            ),
            Padding(
              padding: EdgeInsets.symmetric(vertical: 10,horizontal: 20),
              child: StreamBuilder<QuerySnapshot>(
              stream: _firestore.collection('productDetails').snapshots(),
              builder: (context,snapshot){
                if(snapshot.hasData) {
                  final productDetails = snapshot.data.docs;
                    for (var eachDetail in productDetails) {
                      if(eachDetail.id==productId)
                        imageUrls=eachDetail.get('imageUrls');
                    }
                  }
                else{
                  CircularProgressIndicator();
                }
                return Card(
                  shadowColor: Colors.lightBlueAccent,
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(25)
                  ),
                  elevation: 9,
                  child: Container(
                      decoration: BoxDecoration(
                        borderRadius:BorderRadius.circular(22)
                      ),
                      padding: EdgeInsets.fromLTRB(10, 15, 10, 15),
                      margin: EdgeInsets.all(5),
                      height: 400,
                      child: CarouselSlider(
                        options:CarouselOptions(
                          height: 380,
                          aspectRatio: 0.25,
                          autoPlayInterval:Duration(seconds: 5),
                          enlargeCenterPage: true,
                          scrollDirection: Axis.horizontal,
                          autoPlay: true,
                        ),
                        items:[
                          for (var imageUrl in imageUrls)
                            buildImageViewer(context,imageUrl),
                        ],
                      )
                  ),
                );
                }

              ),
            ),
            Padding(
              padding: EdgeInsets.symmetric(vertical: 20,horizontal: 10),
              child: DetailsTable(productId:productId,productName:productName),
            ),
            Container(
              margin: EdgeInsets.all(15),
              height:100,
              child: Padding(
                padding: const EdgeInsets.all(15),
                child: RaisedButton(
                    onPressed:(){
                      Navigator.push(context,MaterialPageRoute(builder: (_){
                        return PaymentScreen();
                      }));
                    },
                    color: Colors.lightBlue[900],
                    child:Text("Place Order",
                      style: TextStyle(
                          fontSize: 25,
                          fontWeight: FontWeight.bold,
                          color: Colors.yellowAccent
                      ),)),
              ),
            ),
          ],
        ),
      ),
    );;
  }

  GestureDetector buildImageViewer(BuildContext context,String imageUrl) {
    return GestureDetector(
                      onTap:(){
                        Navigator.push(context, MaterialPageRoute(builder: (_){
                          return HeroAnimation1(url: imageUrl);
                        }));
                      },
                      child:Column(children: [
                        Expanded(
                          child: CachedNetworkImage(
                            imageUrl:imageUrl,
                            imageBuilder: (context, imageProvider) => Container(
                              decoration: BoxDecoration(
                                image: DecorationImage(
                                  image: imageProvider,
                                  fit: BoxFit.fill,
                                ),
                              ),
                            ),
                            placeholder: (context, url) => Center(child: CircularProgressIndicator()),
                            errorWidget: (context, url, error) => Icon(Icons.error),
                          ),
                        ),
                      ])
                    );
  }
}


